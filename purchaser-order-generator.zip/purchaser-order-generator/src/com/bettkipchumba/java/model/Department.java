package com.bettkipchumba.java.model;

public class Department {
}
