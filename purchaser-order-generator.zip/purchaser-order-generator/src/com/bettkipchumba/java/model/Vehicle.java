package com.bettkipchumba.java.model;

public class Vehicle {
}
