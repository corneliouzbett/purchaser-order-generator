package com.bettkipchumba.java.db;

public class LpoDocument {
}
